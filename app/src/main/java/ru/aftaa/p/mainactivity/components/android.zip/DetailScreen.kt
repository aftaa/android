package ru.aftaa.p.mainactivity.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import ru.aftaa.p.mainactivity.data.model.Photo
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun DetailScreen(
    initialImageIndex: Int,
    photos: List<Photo>,
    onBackClick: () -> Unit
) {
    BackHandler {
        onBackClick()
    }
    var currentPage by remember { mutableIntStateOf(initialImageIndex) }
    val pagerState = rememberPagerState(
        initialPage = initialImageIndex,
        pageCount = { photos.size }
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "${currentPage + 1} / ${photos.size}",
                        style = androidx.compose.material3.MaterialTheme.typography.titleMedium
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Назад"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color.Black)
        ) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize()
                // userScrollEnabled = true ← по умолчанию!
            ) { page ->
                ZoomableImage(
                    imageUrl = photos[page].fullImageUrl,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}